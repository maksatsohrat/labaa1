fun main(args: Array<String>) {
    val x = 2
    print(x + (x*x*x/3) + (x*x*x*x*x/5) + (x*x*x*x*x*x*x/7) + (x*x*x*x*x*x*x*x*x/9) + (x*x*x*x*x*x*x*x*x*x*x/11))
}